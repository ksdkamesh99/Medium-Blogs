def welcome():
    print("Welcome Amigos")
