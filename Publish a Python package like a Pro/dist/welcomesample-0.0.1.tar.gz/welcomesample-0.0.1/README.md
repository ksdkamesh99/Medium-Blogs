# WelcomeSample

This is a welcome package which prints a welcome message